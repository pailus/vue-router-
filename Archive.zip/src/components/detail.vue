<template>
    <div>
        <img :src="gambar" alt="" class="img-fluid">
        <h3>{{title}}</h3>
    </div>
</template>


<script>
export default {
    name:'detail',
    data(){
        return {
            gambar : this.$route.params.pid,
            title: this.$route.params.title,
        }
    }
}
</script>