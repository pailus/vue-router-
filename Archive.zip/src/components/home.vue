<template>
    <div class="row">
        <div class="col-md-8 col-sm-6 col-lg-8 scroll-y">
        <div class="row">
        <div class="col-md-3 col-sm-6 col-lg-2" v-for="(gambar, index) in gambar" :key="index">
            <div class="harga">{{gambar.harga}}</div>
            <div v-if="gambar.gambar != 'null'">
            <img keep-alive="on"  :src="gambar.gambar" alt="" class="img-fluid fix-gambar" @click="addProduct(index)">
            </div>
            <div v-else>
            <img  src="https://via.placeholder.com/600/92c952" alt="" class="img-fluid fix-gambar" @click="addProduct(index)">
            </div>
            <p>{{gambar.nama}}</p>
        </div>
        </div>
        </div>
        <div class="col-md-4 col-sm-6 col-lg-4 checkout">
           
            <div v-for="(product, index) in product" :key="index" class="row keranjang">
                <div class="col-md-12 keranjang">
                    <div class="item-keranjang">  
                    <div class="nama-product">
                         {{product.nama}}
                    </div>
                    <div class="harga-product">
                        {{product.harga}}
                    </div>
                        <div class="button-quantity">
                            <button class="quantity">-</button> <input class="space" type="text" disabled :value="product.quantity"><button class="quantity">+</button>
                        </div>
                   
                      </div>
                  </div>
            </div>
           
        </div>
    
    
    </div>

</template>
<script>
import axios from 'axios'
// import { async } from 'q'
export default {
    name: 'home',
    data(){
        return{
            quantity:1,
            gambar : [],
            product: [],
            // checkExist:[]
        }
    },
    methods:{
    
        addProduct(index){
        
          var found = false     
            for( var i=0; i < this.product.length  ; i++){
               if(this.product[i].id == this.gambar[index].id){
                   this.product[i].quantity +=1 
                   found = true
                   break;
                  
               }
           }

         if(!found ){
            this.product.push({
                id:this.gambar[index].id,
                nama:this.gambar[index].nama,
                harga:this.gambar[index].harga,
                quantity:this.quantity})
            console.log('tidak ketemu')
        }
            }
        
        
    },

    created(){
        axios.get('https://demo-pos.kedaidesa.id/master/daftar/productJson')
        .then(res=> this.gambar = res.data.data)
        .catch(console.log('error'))
    },
    // methods:{

    //     // goTodetail( url, title){
    //     //     this.$router.push({
    //     //         name:'detail', 
    //     //         params:{pid:url,
    //     //         title:title},
                
    //     //     })
    //     }
    // }
}
</script>

<style  scoped>

    .item-keranjang{
        display: flex;
        flex-direction: row;
        width: 100%;
        height: 5vh;
        /* font-size: 10px; */
        /* border-bottom: #e4e8ea 0.5px solid; */
        
        
    }

    @media only screen  and (min-device-width : 375px)  and (max-device-width : 800px) {
        .item-keranjang{
            font-size: 12px;

        }
      }

    .harga-product{
        /* justify-content: end; */
        flex: 1;
        font-weight: bold;
        text-align-last: right;
        /* border: 1px #ccc solid; */
    }
    .nama-product{
        flex:3;
        font-weight: bolder;
        color: gray;
        
    }
    .quantity{
        /* border-radius:50%; */
        z-index: 2;
        height: 27px;
        width: 27px;
        text-align-last: center;
        border: 1px green solid;
        
    }
    .button-quantity{
        flex:1.2;
        text-align-last: right;
    }
    .scroll-y{
        height: 85vh;
        overflow-y: scroll;
    }
    .keranjang{
        border: black 10px;
        /* position: fixed */
        text-align: left;
        display: flex;
        justify-content:space-between;
        margin-bottom: 8px;
        /* height: 100vh; */
        /* overflow-y: scroll; */
    }
    .fix-gambar{
        height: 160px !important;
        width: 160px !important; 
        object-fit: cover;
        

    }
    .harga{
        z-index: 999;
        background-color: rgba(241, 1, 1, 0.7);
        color: white;
        width: 60px;
        opacity: 90%;
        text-align-last: right;
        padding-right: 10px;
        margin-right: 8%;
        margin-left: auto;
        margin-bottom: -12%;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        

    }
    .footer {
    position: fixed;
    height: 100px;
    bottom: 0;
    width: 100%;
    background-color: green;
}
.space{
    /* display:inline; */
    width: 30px;
    border: none;
    text-align-last: center;
    font-weight: bolder;
}
.checkout{
    border-left:#ccc 1px solid; 
    height: 76vh;
    border-bottom: gray 2px solid;
    overflow-y: scroll;
    

    
}
</style>