<template>
    <div class="container">
        
        <label for="name">Nama</label>
        <input type="text" class="form-control" name="nama" v-model="nama" @keyup.enter="kirim()">
        <button @click="kirim()" >Kirim</button>
    </div>
</template>

<script>
export default {
    name:'contact',
    data(){
        return{
            nama:''
        }

    },
    methods:{
        kirim(){
            this.nama = this.input.nama
        }
    }
}
</script>