<template>
    <div class="row">
    <div class="col-md-4" style="margin-top:20px;" v-for="(article, index) in article" :key="index">
        <div class="card">
            <div class="card-header">
                <h3>
                    {{article.title}}
                </h3>

            </div>
            <div class="card-body">
                {{article.body}}
            </div>
        </div>

    </div>
    </div>
</template>

<script>
import Axios from 'axios'
export default {
    name:'blog',
    data(){
        return{
            article:[]
        }
    },
    created(){
        Axios.get('https://jsonplaceholder.typicode.com/posts?_limit=6')
        .then(res=> this.article = res.data)
    }
}
</script>