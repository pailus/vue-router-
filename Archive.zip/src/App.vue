<template>
  <div id="app">
    <div class="navbar navbar-expand-lg fixed-top navbark-dark bg-success">
      <div class="container">
        <router-link to="/" class="navbar-brand putih">Home</router-link>
        <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarResponsive" aria-expanded="false" aria-label="Toggle Navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav">
            <li class="nav-item putih">
              <router-link class="nav-link putih" to='/blog'>Blog</router-link>
            </li>
            <li class="nav-item putih">
              <router-link class="nav-link putih" to='/service'>Service</router-link>
            </li>
            <li class="nav-item putih">
              <router-link class="nav-link putih" to='/contact'>contact</router-link>
            </li>
          </ul>
        </div>
      </div>

    </div>

    <div class="content">
      <transition name="moveInUp">
        <router-view/>
      </transition>
    </div>
    <div class="footer">
        <div class="transparent-footer">

        </div>
        <div class="button-checkout">

        </div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'app',
  components: {
    
  }
}
</script>

<style>
@import url('https://bootswatch.com/4/cosmo/bootstrap.min.css');
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

.transparent-footer{
  flex: 7;
  

}
.button-checkout{
  flex: 3.98;
  background-color: grey;

}
.content{
  margin-left: 5%;
  margin-top: 5%;
  margin-right: 2%;
  margin-left: 2%;

}

.putih{
  color: white;
}
.putih:hover{
  color: beige
}
.router-link-active{
  color: #2c3e50
}

.moveInUp-enter-active{
  animation: fadeIn 2s ease-in;
}
@keyframes fadeIn{
  0%{
    opacity: 0;
  }
  50%{
    opacity: 0.5;
  }
  100%{
    opacity: 1;
  }
}

.moveInUp-leave-active{
  animation: moveInUp .3s ease-in;
}
@keyframes moveInUp{
 0%{
  transform: translateY(0);
 }
  100%{
  transform: translateY(-400px);
 }
}
.footer {
    position: fixed;
    display: flex;
    flex-direction: row;
    height: 50px;
    bottom: 0;
    width: 100%;
    /* background-color:#bbb9b9d4 */
}

</style>
